package com.example.tugasakhirpraktikum;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "crud.db";
    private static final String TABLE_NAME = "data_table";
    private static final String COL_ID = "ID";
    private static final String COL_DATA = "DATA";

    private static final String COL_AGE = "AGE";
    private static final String COL_MAJOR = "MAJOR";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_NAME + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_DATA + " TEXT, " +
                COL_AGE + " INTEGER, " +
                COL_MAJOR + " TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // Insert Data
    public boolean insertData(String data, int age, String major) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_DATA, data);
        contentValues.put(COL_AGE, age);
        contentValues.put(COL_MAJOR, major);
        long result = db.insert(TABLE_NAME, null, contentValues);
        return result != -1;
    }

    // Update Data
    public boolean updateData(String id, String newData, int age, String major) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_DATA, newData);
        contentValues.put(COL_AGE, age);
        contentValues.put(COL_MAJOR, major);
        db.update(TABLE_NAME, contentValues, "ID = ?", new String[]{id});
        return true;
    }

    // Delete Data
    public Integer deleteData(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_NAME, "ID = ?", new String[]{id});
    }

    // Get All Data
    public Cursor getAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
    }
}
