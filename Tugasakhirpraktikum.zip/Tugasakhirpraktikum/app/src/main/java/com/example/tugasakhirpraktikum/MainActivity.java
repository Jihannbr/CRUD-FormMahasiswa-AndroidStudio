package com.example.tugasakhirpraktikum;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper db;
    EditText etInput, etAge, etMajor;
    Button btnAdd, btnEdit, btnDelete;
    ListView lvData;
    ArrayAdapter<String> adapter;
    ArrayList<String> dataList;
    String selectedId = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inisialisasi
        db = new DatabaseHelper(this);
        etInput = findViewById(R.id.et_input);
        etAge = findViewById(R.id.et_age);
        etMajor = findViewById(R.id.et_major);
        btnAdd = findViewById(R.id.btn_add);
        btnEdit = findViewById(R.id.btn_edit);
        btnDelete = findViewById(R.id.btn_delete);
        lvData = findViewById(R.id.lv_data);
        dataList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, dataList);
        lvData.setAdapter(adapter);

        loadData();

        // Tambah Data
        btnAdd.setOnClickListener(v -> {
            String input = etInput.getText().toString();
            String ageText = etAge.getText().toString();
            String major = etMajor.getText().toString();

            if (input.isEmpty() || ageText.isEmpty() || major.isEmpty()) {
                Toast.makeText(this, "Semua input harus diisi", Toast.LENGTH_SHORT).show();
            } else {
                int age = Integer.parseInt(ageText);
                if (db.insertData(input, age, major)) {
                    loadData();
                    etInput.setText("");
                    etAge.setText("");
                    etMajor.setText("");
                }
            }
        });

        // Pilih Data
        lvData.setOnItemClickListener((adapterView, view, i, l) -> {
            String[] parts = dataList.get(i).split(": |, Umur: |, Jurusan: ");
            selectedId = parts[0];
            etInput.setText(parts[1]);
            etAge.setText(parts[2]);
            etMajor.setText(parts[3]);
        });

        // Edit Data
        btnEdit.setOnClickListener(v -> {
            String input = etInput.getText().toString();
            int age = Integer.parseInt(etAge.getText().toString());
            String major = etMajor.getText().toString();
            db.updateData(selectedId, input, age, major);
            loadData();
        });

        // Delete Data
        btnDelete.setOnClickListener(v -> {
            db.deleteData(selectedId);
            loadData();
        });
    }

    private void loadData() {
        dataList.clear();
        Cursor cursor = db.getAllData();
        while (cursor.moveToNext()) {
            dataList.add(cursor.getString(0) + ": " +
                    cursor.getString(1) + ", Umur: " +
                    cursor.getString(2) + ", Jurusan: " +
                    cursor.getString(3));
        }
        adapter.notifyDataSetChanged();
    }
}
